import Foundation

/// Unified Protocol for BLEDDM / BLEDOM / Lotus Lantern Controllers
/// Supports both short (3-8 byte) and long (9-byte) command formats.
struct LEDProtocol {
    
    enum CommandType: UInt8 {
        case power = 0x04
        case brightness = 0x01
        case speed = 0x02
        case color = 0x05
        case mode = 0x06
    }
    
    // MARK: - Power
    static func power(_ on: Bool) -> [UInt8] {
        // EXACT 9-BYTE FORMAT FROM linuxthings.co.uk
        if on {
            return [0x7E, 0x00, 0x04, 0xF0, 0x00, 0x01, 0xFF, 0x00, 0xEF]
        } else {
            return [0x7E, 0x00, 0x04, 0x00, 0x00, 0x00, 0xFF, 0x00, 0xEF]
        }
    }
    
    // MARK: - Color
    static func color(r: Int, g: Int, b: Int) -> [UInt8] {
        let r = UInt8(clamping: r)
        let g = UInt8(clamping: g)
        let b = UInt8(clamping: b)
        // EXACT 9-BYTE: 7E 00 05 03 RR GG BB 00 EF
        return [0x7E, 0x00, 0x05, 0x03, r, g, b, 0x00, 0xEF]
    }
    
    // MARK: - Brightness
    static func brightness(_ value: Int) -> [UInt8] {
        let val = UInt8(clamping: value)
        // EXACT 9-BYTE: 7E 00 01 ZZ 00 00 00 00 EF
        return [0x7E, 0x00, 0x01, val, 0x00, 0x00, 0x00, 0x00, 0xEF]
    }
    
    // MARK: - Speed
    static func speed(_ value: Int) -> [UInt8] {
        let val = UInt8(clamping: value)
        // Standard 9-byte speed
        return [0x7E, 0x00, 0x02, val, 0x00, 0x00, 0x00, 0x00, 0xEF]
    }
    
    // MARK: - Mode
    static func mode(_ value: UInt8) -> [UInt8] {
        // Standard 9-byte mode
        return [0x7E, 0x00, 0x06, value, 0x00, 0x00, 0x00, 0x00, 0xEF]
    }
}
