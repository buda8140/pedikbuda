import Foundation
import CoreBluetooth

struct DiscoveredDevice: Identifiable {
    let id: UUID
    let peripheral: CBPeripheral
    let rssi: Int
    let name: String
}

class BluetoothManager: NSObject, ObservableObject {
    private var centralManager: CBCentralManager!
    private var writeCharacteristic: CBCharacteristic?
    
    @Published var isConnected = false
    @Published var isPoweredOn = false
    @Published var connectionStatus = "Disconnected"
    @Published var discoveredDevices: [DiscoveredDevice] = []
    @Published var isScanning = false
    @Published var logs: [String] = []
    
    var connectedPeripheral: CBPeripheral?
    
    // UUIDs for BLEDDM / Lotus Lantern
    private let serviceUUIDs = [CBUUID(string: "FFF0"), CBUUID(string: "FFE0")]
    private let writeCharacteristics = [
        CBUUID(string: "FFE9"), // Primary for ELK-BLEDDM
        CBUUID(string: "FFE1"), // Common alternative
        CBUUID(string: "FFF3"), 
        CBUUID(string: "FFF4")
    ]
    
    // Reconnection Logic
    private var reconnectAttempt = 0
    private var reconnectTimer: Timer?
    private let maxReconnectAttempts = 10
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
        log("System initialized")
    }
    
    func log(_ message: String) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss.SSS"
        let timestamp = formatter.string(from: Date())
        let fullMessage = "[\(timestamp)] \(message)"
        
        DispatchQueue.main.async {
            self.logs.append(fullMessage)
            if self.logs.count > 100 { self.logs.removeFirst() }
            print(fullMessage) // Console backup
        }
    }
    
    func startScanning() {
        guard centralManager.state == .poweredOn else { 
            log("Scan failed: Bluetooth not powered on")
            return 
        }
        
        isScanning = true
        // We don't removeAll here to avoid flickering during auto-refresh, 
        // but we will update them.
        log("Scanning started (ALL peripherals + Connected)")
        
        // 1. Scan for new devices (AllowDuplicates = true for real-time RSSI updates)
        centralManager.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
        
        // 2. Retrieve peripherals already connected by the system
        fetchConnectedDevices()
    }
    
    func fetchConnectedDevices() {
        // Try to find devices already connected by iOS (Settings -> Bluetooth)
        // These won't show up in scan results
        let connected = centralManager.retrieveConnectedPeripherals(withServices: serviceUUIDs)
        for peripheral in connected {
            handleDiscoveredPeripheral(peripheral, rssi: -50, isConnectedBySystem: true)
        }
        
        // Also try general "connected" retrieve if specific services fail
        // Note: passing empty array to retrieveConnectedPeripherals is not allowed in iOS
    }
    
    func refresh() {
        stopScanning()
        DispatchQueue.main.async {
            self.discoveredDevices.removeAll()
            self.startScanning()
        }
    }
    
    func stopScanning() {
        isScanning = false
        centralManager.stopScan()
        log("Scanning stopped")
    }
    
    func connect(to peripheral: CBPeripheral) {
        stopScanning()
        connectedPeripheral = peripheral
        connectedPeripheral?.delegate = self
        connectionStatus = "Connecting..."
        log("Connecting to: \(peripheral.name ?? "Unknown") [\(peripheral.identifier.uuidString)]")
        centralManager.connect(peripheral, options: [
            CBConnectPeripheralOptionNotifyOnDisconnectionKey: true
        ])
    }
    
    func disconnect() {
        if let peripheral = connectedPeripheral {
            log("User requested disconnect from: \(peripheral.name ?? "Unknown")")
            centralManager.cancelPeripheralConnection(peripheral)
        }
        reconnectTimer?.invalidate()
        reconnectAttempt = 0
    }
    
    func togglePower() {
        let newState = !isPoweredOn
        send(LEDProtocol.power(newState))
        isPoweredOn = newState
        Haptics.play(.medium)
    }
    
    func setPower(on: Bool) {
        send(LEDProtocol.power(on))
        isPoweredOn = on
    }
    
    func setColor(r: Int, g: Int, b: Int) {
        send(LEDProtocol.color(r: r, g: g, b: b))
    }
    
    func setBrightness(_ value: Int) {
        send(LEDProtocol.brightness(value))
    }
    
    func setEffectSpeed(_ value: Int) {
        send(LEDProtocol.speed(value))
    }
    
    func setMode(_ value: UInt8) {
        send(LEDProtocol.mode(value))
    }
    
    private let bleQueue = DispatchQueue(label: "com.ledglow.ble")
    
    func sendRawHex(_ hex: String) {
        let cleaned = hex.replacingOccurrences(of: " ", with: "").uppercased()
        guard let data = cleaned.hexData() else {
            log("TX Error: Invalid HEX")
            return
        }
        send(Array(data))
    }
    
    private func send(_ bytes: [UInt8]) {
        bleQueue.async {
            // DOUBLE-SEND LOGIC (50ms delay) for reliability
            self.sendDirect(bytes)
            Thread.sleep(forTimeInterval: 0.05)
            self.sendDirect(bytes)
        }
    }
    
    private func sendInitSequence() {
        bleQueue.async {
            self.log("Activating Hardware (Verified 9-Byte Mode)...")
            // Wait 200ms after connection before first command as per linuxthings specs
            Thread.sleep(forTimeInterval: 0.2)
            
            // Send exact Power ON packet (Double Shot)
            let onPacket = LEDProtocol.power(true)
            self.sendDirect(onPacket)
            Thread.sleep(forTimeInterval: 0.05)
            self.sendDirect(onPacket)
            
            self.log("Init complete. Power ON sent.")
        }
    }

    private func sendDirect(_ bytes: [UInt8]) {
        guard let peripheral = connectedPeripheral, let characteristic = writeCharacteristic else { 
            log("TX Skip: Not connected or no write char")
            return 
        }
        
        // Final length validation
        guard bytes.count == 9 else {
            log("TX Warning: Packet length is \(bytes.count) (Expected 9)")
            return
        }

        let data = Data(bytes)
        // MUST USE .withoutResponse for ELK-BLEDDM hardware
        peripheral.writeValue(data, for: characteristic, type: .withoutResponse)
        
        let hexString = bytes.map { String(format: "%02X", $0) }.joined(separator: "")
        log("TX: \(hexString)")
    }
    
    private func handleDiscoveredPeripheral(_ peripheral: CBPeripheral, rssi: Int, isConnectedBySystem: Bool = false) {
        let name = peripheral.name ?? "Unknown"
        let uuid = peripheral.identifier.uuidString
        
        // BROAD FILTER
        let lowerName = name.lowercased()
        let isLED = lowerName.contains("led") || 
                    lowerName.contains("ble") || 
                    lowerName.contains("elk") || 
                    lowerName.contains("dm") ||
                    lowerName.contains("om")
        
        if isLED || name != "Unknown" {
            DispatchQueue.main.async {
                if let index = self.discoveredDevices.firstIndex(where: { $0.id == peripheral.identifier }) {
                    // Update existing
                    self.discoveredDevices[index] = DiscoveredDevice(
                        id: peripheral.identifier, 
                        peripheral: peripheral, 
                        rssi: isConnectedBySystem ? -30 : rssi, 
                        name: isConnectedBySystem ? "\(name) (Connected)" : name
                        
                    )
                } else {
                    // Add new
                    self.log("Found: \(name) [\(uuid)] (\(rssi)dBm)\(isConnectedBySystem ? " [SYSTEM CONNECTED]" : "")")
                    self.discoveredDevices.append(DiscoveredDevice(
                        id: peripheral.identifier, 
                        peripheral: peripheral, 
                        rssi: isConnectedBySystem ? -30 : rssi, 
                        name: isConnectedBySystem ? "\(name) (Connected)" : name
                    ))
                }
                // Always sort by signal strength
                self.discoveredDevices.sort { $0.rssi > $1.rssi }
            }
        }
    }
    
    private func handleDisconnection() {
        isConnected = false
        writeCharacteristic = nil
        
        if reconnectAttempt < maxReconnectAttempts {
            reconnectAttempt += 1
            let delay = min(pow(2.0, Double(reconnectAttempt)), 30.0)
            connectionStatus = "Retrying in \(Int(delay))s (#\(reconnectAttempt))"
            log("Connection lost. Retry #\(reconnectAttempt) in \(Int(delay))s")
            
            reconnectTimer?.invalidate()
            reconnectTimer = Timer.scheduledTimer(withTimeInterval: delay, repeats: false) { [weak self] _ in
                guard let self = self, let p = self.connectedPeripheral else { return }
                self.log("Automatic reconnection attempt...")
                self.centralManager.connect(p, options: nil)
            }
        } else {
            connectionStatus = "Disconected"
            log("Max reconnection attempts reached")
        }
    }
}

extension BluetoothManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        log("Bluetooth state: \(central.state == .poweredOn ? "ON" : "OFF (\(central.state.rawValue))")")
        if central.state == .poweredOn {
            startScanning()
        } else {
            connectionStatus = "Bluetooth Unavailable"
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi: NSNumber) {
        handleDiscoveredPeripheral(peripheral, rssi: rssi.intValue)
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        isConnected = true
        connectionStatus = "Connected"
        reconnectAttempt = 0
        reconnectTimer?.invalidate()
        log("Connected to \(peripheral.name ?? "Device"). Discovering services...")
        peripheral.discoverServices(nil) // Discover all services for robustness
    }
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        log("Connect failed: \(error?.localizedDescription ?? "Unknown error")")
        handleDisconnection()
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        log("Disconnected: \(error?.localizedDescription ?? "Clean disconnect")")
        handleDisconnection()
    }
}

extension BluetoothManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard let services = peripheral.services else { 
            log("No services found")
            return 
        }
        
        for service in services {
            log("Service found: \(service.uuid)")
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let characteristics = service.characteristics else { return }
        
        for characteristic in characteristics {
            log("  - Char: \(characteristic.uuid) [\(characteristic.properties.contains(.writeWithoutResponse) ? "W" : "")]")
            
            // Matches any of our target write UUIDs
            if writeCharacteristics.contains(characteristic.uuid) {
                if writeCharacteristic == nil {
                    writeCharacteristic = characteristic
                    log("Matched Write Characteristic: \(characteristic.uuid)")
                    
                    // Hardware Initialization
                    sendInitSequence()
                }
            }
        }
    }
}

extension String {
    func hexData() -> Data? {
        var data = Data(capacity: count / 2)
        let regex = try! NSRegularExpression(pattern: "[0-9a-f]{1,2}", options: .caseInsensitive)
        regex.enumerateMatches(in: self, range: NSRange(location: 0, length: count)) { match, _, _ in
            if let match = match {
                let byteString = (self as NSString).substring(with: match.range)
                if let num = UInt8(byteString, radix: 16) {
                    data.append(num)
                }
            }
        }
        return data.count > 0 ? data : nil
    }
}
